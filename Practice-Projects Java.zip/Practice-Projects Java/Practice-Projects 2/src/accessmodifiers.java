public class accessmodifiers {
	private int privateNum = 56;
    protected String protectedStr = "A test Program";
    public float publicFloat = 8.45f;

    private void privateMethod() {
        System.out.println("This is a private method.");
    }

    protected void protectedMethod() {
        System.out.println("This is a protected method.");
    }

    public void publicMethod() {
        System.out.println("This is a public method.");
    }

	public static void main(String[] args) {
		accessmodifiers example = new accessmodifiers();     
        System.out.println("Private Member: " + example.privateNum);
        example.privateMethod();      
        System.out.println("Protected Member: " + example.protectedStr);
        example.protectedMethod();       
        System.out.println("Public Member: " + example.publicFloat);
        example.publicMethod();
		
	}
}
