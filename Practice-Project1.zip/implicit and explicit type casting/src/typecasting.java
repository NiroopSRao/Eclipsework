
public class typecasting {

	public static void main(String[] args) {
		
		int Int = 72;
        long Long = Int;
        float Float = Long;
        
        System.out.println("Widening casting or Implicit Type Casting:");
        System.out.println("myInt = " + Int);
        System.out.println("myLong = " + Long);
        System.out.println("myFloat = " + Float);
        
        double Double = 754.25;
        long Long2 = (long) Double;
        int Int2 = (int) Long2;
        
        System.out.println("\nNarrowing casting or Explicit Type Casting:");
        System.out.println("myDouble = " + Double);
        System.out.println("myLong2 = " + Long2);
        System.out.println("myInt2 = " + Int2);

	}

}
